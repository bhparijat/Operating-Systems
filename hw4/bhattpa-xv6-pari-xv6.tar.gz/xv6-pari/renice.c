#include "types.h"
#include "user.h"

#define MAX_NICE_VALUE 40
#define MIN_NICE_VALUE 1
int main(int argc, char **argv){


  int i = 0;
  
  for(i=0;i<argc;i++){

    // printf(1,"%s ",argv[i]); 
    continue;
  }


  // printf(1,"\n");
  if(argc<=2){

    printf(1,"Few arguments found\n");

    exit();

  }
  
  int renice_value = atoi(argv[1]);

  if (renice_value > MAX_NICE_VALUE || renice_value <MIN_NICE_VALUE){


   
    printf(1,"The renice value is not correct\n");
    exit();

  }
  for(i = 2; i<argc; i++){


    int pid = atoi(argv[i]);
      

      int status = renice(pid,renice_value);

    if(status==2){

      printf(1,"something wrong wiith pid = %d \n",pid);

    }

  }

  exit();
}
