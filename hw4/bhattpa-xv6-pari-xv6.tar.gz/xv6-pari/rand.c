#include "rand.h"
#include "types.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "x86.h"
#include "proc.h"
#include "spinlock.h"


static unsigned  long next = 1;

int ticks_function(void){

  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
  // return sys_uptime();
}
int rand(void) {
  next = next * 1103515245 + 12345;

  unsigned int y = (unsigned)ticks_function();
 
 int x = ((unsigned)(next/65536) % RAND_MAX);
 srand(y);

 return x;

}

void srand(unsigned seed) {
  next = seed;
}
