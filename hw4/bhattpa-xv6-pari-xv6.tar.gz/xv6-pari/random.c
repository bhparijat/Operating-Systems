#include "types.h"
#include "user.h"



int main(void){


  int x = random();

  printf(1,"random number is: %d\n",x);

  exit();
}
