#include "types.h"
#include "user.h"
int main(int argc, char **argv){


  if(argc<=2){

    printf(1,"few arguments found\n");
    exit();

  }

  int nice_value = atoi(argv[1]);

  
  int status = renice(getpid(),nice_value);
  
  // printf(1,"status=%d , nice = %d\n",status,nice_value);
  if(status){


    printf(1,"Something went wrong \n");
    exit();

  }


  char *param[2] = {"5",0};
  /*
  if(argc>3){


    printf(1,"argc more than 3 = %d,%s\n",argc,argv[3]);
    param[0]= argv[3];

    }*/
  // printf(1,"%d,%s\n",nice_value,argv[2]);
 
  printf(1,"goinng to call exec\n");
 exec(argv[2],param);

 printf(1,"returned from exec\n");
  exit();
}
